module.exports = { calc : function(strToCalc){ 
	return eval(strToCalc)
}};