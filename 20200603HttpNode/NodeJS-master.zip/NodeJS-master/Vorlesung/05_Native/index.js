const sleep = require('sleep');

console.log("Hi");
sleep.sleep(4);
console.log("World");


//npm install --save sleep --msvs_version=2015
