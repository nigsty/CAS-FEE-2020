const a = require("./a");
const b = require("./b");
a.showObject();
b.showObject();