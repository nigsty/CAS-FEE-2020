const numbers = require('./numbers.js');
numbers(0, 50);
