import {number} from './numbersES2016'
number(10,20);