import { Component, State, h } from '@stencil/core';

interface Todo {
  label: string;
  done: boolean;
}

@Component({
  tag: "my-todos",
  styleUrl: "my-todos.css",
  shadow: true
})
export class MyTodos {
  @State() todos: Todo[] = [
    { label: "Milch kaufen", done: false },
    { label: "Auto vorführen", done: true },
    { label: "iOS downgraden", done: true },
    { label: "Rasen mähen", done: false }
  ];

  private createTodo(label: string): void {
    this.todos = this.todos.concat({ label, done: false });
  }

  private toggleTodo(i: number): void {
    const newTodos = this.todos.slice();
    newTodos[i].done = !newTodos[i].done;

    this.todos = newTodos;
  }

  private getSortedTodos(): Todo[] {
    return this.todos.sort((a, b) =>
      a.done === b.done ? 0 : (a.done ? 1 : -1)
    );
  }

  private onKeyPress(e: KeyboardEvent): void {
    const target = e.target as HTMLInputElement;

    if (e.key === 'Enter') {
      this.createTodo(target.value);
      target.value = '';
    }
  }

  render() {
    return (
      <div class="todos">
        {this.getSortedTodos().map((todo, i) =>
          <div class="todo" key={todo.label}>
            <input type="checkbox" checked={todo.done} onChange={() => this.toggleTodo(i)} />
            <span>{todo.label}</span>
          </div>
        )}

        <input type="text" placeholder="Neues Todo" onKeyPress={e => this.onKeyPress(e)}/>
      </div>
    );
  }
}
