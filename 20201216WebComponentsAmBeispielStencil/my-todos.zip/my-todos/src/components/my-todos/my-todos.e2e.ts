import { newE2EPage } from "@stencil/core/testing";

describe("my-todos", () => {
  it("renders default todos", async () => {
    const page = await newE2EPage();

    await page.setContent("<my-todos></my-todos>");

    const element = await page.find("my-todos");
    const todos = await element.shadowRoot.querySelectorAll(".todo");

    expect(todos.length).toEqual(4);
  });

  it("adds a new todo (at the right position)", async () => {
    const page = await newE2EPage();

    await page.setContent("<my-todos></my-todos>");

    const element = await page.find("my-todos");

    await page.evaluate(() => {
      const element = document.querySelector("my-todos");
      const input = element.shadowRoot.querySelector("input[type=text]") as HTMLInputElement;

      input.value = "My test todo!";
      input.focus();
    });

    await page.keyboard.press("Enter");
    await page.waitForChanges();

    const todos = await element.shadowRoot.querySelectorAll(".todo");

    expect(todos.length).toEqual(5);
    expect(todos[2].textContent).toBe("My test todo!");
  });
});
