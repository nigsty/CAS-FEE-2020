class Calculator {
    constructor() {
    }

}
