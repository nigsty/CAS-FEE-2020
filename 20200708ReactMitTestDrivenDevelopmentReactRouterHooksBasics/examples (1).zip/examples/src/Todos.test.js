import React from "react";
import { render, fireEvent } from "@testing-library/react";
import Todos from "./Todos";

test("initially renders four todos", () => {
  const { getByText } = render(<Todos />);

  expect(getByText("Milch kaufen")).toBeInTheDocument();
  expect(getByText("Auto vorführen")).toBeInTheDocument();
  expect(getByText("iOS downgraden")).toBeInTheDocument();
  expect(getByText("Rasen mähen")).toBeInTheDocument();
});

test("adding a todo", () => {
  const { getByPlaceholderText, getByText } = render(<Todos />);
  const input = getByPlaceholderText("Neues Todo");

  fireEvent.keyDown(input, { key: "Enter", target: { value: "HSR besuchen" } })

  expect(getByText("HSR besuchen")).toBeInTheDocument();
});
