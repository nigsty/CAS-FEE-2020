import React from "react";

export default class MyName extends React.Component {
  constructor() {
    super();
    this.state = { name: "" };
  }

  setName(name) {
    this.setState({ name });
  }

  render() {
    return (
      <div>
        <input
          placeholder="My name"
          onInput={e => this.setName(e.target.value)}
        />

        {this.state.name &&
          <span>Hi {this.state.name}!</span>
        }
      </div>
    );
  }
}
