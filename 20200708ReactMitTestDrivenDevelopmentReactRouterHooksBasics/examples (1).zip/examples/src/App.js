import React from "react";
import { BrowserRouter, Route, Link } from "react-router-dom";
import MyName from "./MyName";
import Seconds from "./Seconds";
import Todos from "./Todos";

function App() {
  return (
    <BrowserRouter>
      <ul>
        <li><Link to="/myName">MyName</Link></li>
        <li><Link to="/seconds">Seconds</Link></li>
        <li><Link to="/todos">Todos</Link></li>
      </ul>

      <Route path="/myName"><MyName /></Route>
      <Route path="/seconds"><Seconds /></Route>
      <Route path="/todos"><Todos /></Route>
    </BrowserRouter>
  );
}

export default App;
