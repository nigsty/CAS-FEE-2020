import React from "react";
import "./Todos.css";

export default class Todos extends React.Component {
  constructor() {
    super();

    this.state = {
      todos: [
        { text: "Milch kaufen", done: false },
        { text: "Auto vorführen", done: true },
        { text: "iOS downgraden", done: true },
        { text: "Rasen mähen", done: false }
      ]
    };
  }

  createTodo(text) {
    if (!text) return
    this.setState({ todos: [ { text, done: false }, ...this.state.todos ] });
  }

  toggleTodo(i) {
    const newTodos = [ ...this.state.todos ];
    newTodos[i].done = !newTodos[i].done;

    this.setState({ todos: newTodos })
  }

  onKeyPress(e) {
    if (e.key === "Enter") {
      this.createTodo(e.target.value);
      e.target.value = "";
    }
  }

  render() {
    return (
      <div className="Todos">
        {this.state.todos.sort((a, b) => a.done - b.done).map((todo, i) => {
          return (
            <div key={i} className="Todo">
              <input type="checkbox" checked={todo.done} onChange={() => this.toggleTodo(i)} />
              {todo.text}
            </div>
          );
        })}

        <input type="text" placeholder="Neues Todo" onKeyDown={e => this.onKeyPress(e)} />
      </div>
    );
  }
}
