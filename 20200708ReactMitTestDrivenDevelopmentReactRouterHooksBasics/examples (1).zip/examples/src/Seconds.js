import React from "react";

export default class Seconds extends React.Component {
  constructor() {
    super();

    this.state = {
      second: 0
    };

    this.interval = setInterval(() => {
      // Erhöhe Sekunde
      this.setState({
        second: this.state.second + 1
      });
    }, 1000);
  }

  componentWillUnmount() {
    clearInterval(this.interval);
  }

  render() {
    return <span>{this.state.second}</span>;
  }
}
