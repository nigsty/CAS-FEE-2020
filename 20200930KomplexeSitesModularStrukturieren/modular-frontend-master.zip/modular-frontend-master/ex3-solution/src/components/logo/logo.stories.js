import React from "react";

import Logo from "./";

export default {
  title: "Atoms/Logo",
  component: Logo,
};

export const Example = () => <Logo />;
