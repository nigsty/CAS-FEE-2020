import React from "react";

import App from "./";

export default {
  title: "Templates/App",
  component: App,
};

export const Preview = () => <App />;
