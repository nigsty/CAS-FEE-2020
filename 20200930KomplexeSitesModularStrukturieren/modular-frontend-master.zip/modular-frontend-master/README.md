# CAS Frontend Engineering

Please fork this repository to go along with the course.

## Server

In each excersise folder run:

- `npm install `
- `npm run start`
- `npm run test`

Then open the following URL in your browser: `http://localhost:8000/`.
