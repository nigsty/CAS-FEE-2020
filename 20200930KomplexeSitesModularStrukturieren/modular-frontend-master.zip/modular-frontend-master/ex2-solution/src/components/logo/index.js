import React from "react";

import "./logo.css";

const Logo = () => <h1 className="logo">A Big Title</h1>;

export default Logo;
