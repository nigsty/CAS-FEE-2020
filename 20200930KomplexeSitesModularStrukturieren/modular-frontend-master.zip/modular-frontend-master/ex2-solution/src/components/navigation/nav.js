import React from "react";

const Nav = ({ children }) => <ul className="nav">{children}</ul>;

export default Nav;
