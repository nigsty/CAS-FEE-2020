module.exports = class TransactionManager {
    constructor() {
    }
};













/*--- TODO (DEMO)
    constructor() {
        this.transactions = [ ];
    }

    addTransaction(newTransaction) {
        this.transactions.push(newTransaction);
    }
 */
