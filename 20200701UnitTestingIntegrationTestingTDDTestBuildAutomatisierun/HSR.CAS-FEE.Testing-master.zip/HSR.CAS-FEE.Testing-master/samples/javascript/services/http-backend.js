/**
 * Declares the interface for Data Access component.
 */
export class HttpBackend {
  hasInMemoryData() { }
  enforceData(data) { }
  loadData(dataAsync) { }
}
