//-start---------------- CAS FEE Test Infrastructure ------------------------\\
/**
 * Load configured / local SUT.
 */
const Transaction = require(process.env.transaction || "./transaction");
//-end------------------ CAS FEE Test Infrastructure ------------------------\\


describe('A new transaction of 25$', function() {

});