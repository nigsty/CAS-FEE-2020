'use strict';

module.exports = class Transaction {
	constructor(accountA, accountB, amount) {}
};
